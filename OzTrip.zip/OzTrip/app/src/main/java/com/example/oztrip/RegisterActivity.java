package com.example.oztrip;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth; // Добавь этот импорт
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import com.google.firebase.auth.FirebaseAuth;
public class RegisterActivity extends AppCompatActivity {
    // Импортируй это


    // Внутри метода обработки нажатия на кнопку (например, btnLogout)


    // Объявляем переменную для Firebase Auth
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        TextView tvError = findViewById(R.id.tvError);
        // Инициализируем Firebase
        mAuth = FirebaseAuth.getInstance();

        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        // Внутри onCreate после инициализации etEmail и etPassword:

        View.OnFocusChangeListener errorCleaner = (view, hasFocus) -> {
            if (hasFocus) {
                tvError.setVisibility(View.GONE);
            }
        };

        etEmail.setOnFocusChangeListener(errorCleaner);
        etPassword.setOnFocusChangeListener(errorCleaner);
        Button btnRegister = findViewById(R.id.btnRegister);
        etEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvError.setVisibility(View.GONE); // Скрываем ошибку, как только начали печатать
            }
            // Остальные методы можно оставить пустыми
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void afterTextChanged(Editable s) {}
        });
        btnRegister.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.length() < 6) {
                tvError.setVisibility(View.VISIBLE);
                tvError.setText("Пароль должен быть минимум 6 символов!");
                return; // Останавливаем выполнение, как и раньше
            }

            // МАГИЯ FIREBASE НАЧИНАЕТСЯ ЗДЕСЬ
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            // ВМЕСТО перехода в MainActivity:
                            Intent intent = new Intent(RegisterActivity.this, ProfileSetupActivity.class);
                            startActivity(intent);
                            finish(); // Завершаем регистрацию, чтобы нельзя было вернуться назад
                        }  else {
                tvError.setVisibility(View.VISIBLE);
                Exception e = task.getException();
                if (e instanceof com.google.firebase.auth.FirebaseAuthUserCollisionException) {
                    tvError.setText("Такой email уже зарегистрирован!");
                } else if (e instanceof com.google.firebase.auth.FirebaseAuthWeakPasswordException) {
                    tvError.setText("Пароль слишком слабый.");
                } else {
                    tvError.setText("Произошла ошибка, попробуйте позже.");
                }
            }
                    });

        });


    }
    @Override
    protected void onStart() {
        super.onStart();
        // Если пользователь УЖЕ авторизован, отправляем его в MainActivity
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }
}