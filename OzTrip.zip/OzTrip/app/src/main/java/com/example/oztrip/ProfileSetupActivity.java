package com.example.oztrip;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ProfileSetupActivity extends AppCompatActivity {
    private EditText etName;
    private ImageView ivAvatar;
    private FirebaseFirestore db;
    private String userId;

    // ПРАВИЛЬНО: Объявляем переменную здесь, на уровне класса
    private androidx.activity.result.ActivityResultLauncher<Intent> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_setup);

        // Инициализируем Launcher ВНУТРИ onCreate, но не переобъявляем тип!
        imagePickerLauncher = registerForActivityResult(
                new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        android.net.Uri imageUri = result.getData().getData();
                        ivAvatar.setImageURI(imageUri);
                    }
                });

// Добавляем проверку:
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, RegisterActivity.class));
            finish();
            return;
        }
        db = FirebaseFirestore.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        etName = findViewById(R.id.etName);
        ivAvatar = findViewById(R.id.ivAvatar);
        // Добавь это поле в класс (рядом с etName и ivAvatar)
         androidx.activity.result.ActivityResultLauncher<Intent> imagePickerLauncher;

// В методе onCreate добавь инициализацию:
        imagePickerLauncher = registerForActivityResult(
                new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        android.net.Uri imageUri = result.getData().getData();
                        ivAvatar.setImageURI(imageUri); // Отображаем фото в ImageView
                        // TODO: Позже здесь будет код для загрузки в Firebase Storage
                    }
                });

// И добавь клик на аватарку:
        ivAvatar.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            imagePickerLauncher.launch(intent);
        });
        Button btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> saveProfile());

    }

    private void saveProfile() {
        String name = etName.getText().toString().trim();
        if (name.isEmpty()) {
            etName.setError("Имя обязательно!");
            return;
        }

        Map<String, Object> user = new HashMap<>();
        user.put("name", name);
        user.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());

        // Сохраняем и ждем ответа от базы данных
        db.collection("users").document(userId)
                .set(user)
                .addOnSuccessListener(aVoid -> {
                    // Переход происходит ТОЛЬКО после успеха
                    startActivity(new Intent(ProfileSetupActivity.this, MainActivity.class));
                    finish();
                })
                .addOnFailureListener(e -> {
                    // Если база не ответила (например, нет интернета)
                    etName.setError("Ошибка сохранения: " + e.getMessage());
                });

        // УДАЛИ ЭТИ СТРОКИ СНИЗУ, ОНИ ТУТ ЛИШНИЕ:
        // startActivity(new Intent(ProfileSetupActivity.this, MainActivity.class));
        // finish();
    }


}
