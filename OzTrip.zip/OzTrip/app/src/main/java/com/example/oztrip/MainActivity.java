package com.example.oztrip;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.Point;
import org.maplibre.android.geometry.LatLng;
import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;

import org.maplibre.android.location.LocationComponent;
import org.maplibre.android.location.LocationComponentActivationOptions;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private java.util.List<org.maplibre.android.geometry.LatLng> pathPoints = new java.util.ArrayList<>();
    private LatLng homeLatLng = new LatLng(40.1792, 44.5134); // Та самая база
    private MapView mapView;
    private MapLibreMap mapLibre;
    // Список всех сохраненных точек (баз)
// Удаляем: private java.util.List<Feature> savedFeatures = new java.util.ArrayList<>();
    private SavedLocation currentlyEditingLocation;
    // Добавляем: Список уникальных "Баз" с уровнями
    private java.util.List<SavedLocation> uniqueLocations = new java.util.ArrayList<>();
    private static final String SAVED_POINTS_SOURCE = "saved-points-source";
    private static final String SAVED_POINTS_LAYER = "saved-points-layer";
    private com.google.android.material.bottomsheet.BottomSheetBehavior sheetBehavior;
    private org.maplibre.android.annotations.Polyline runningLine;
    private org.maplibre.android.annotations.Icon createPremiumMarker(SavedLocation loc) {
        // 0. Если иконка уже была создана ранее — берем из кэша (Экономим ресурсы!)
        if (loc.cachedIcon != null) return loc.cachedIcon;

        int canvasSize = (int) dpToPx(74); // Чуть увеличим под тени
        android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(canvasSize, canvasSize, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);

        float center = canvasSize / 2f;
        float mainCircleRadius = dpToPx(20);
        float arcRadius = mainCircleRadius + dpToPx(4);
        float strokeWidth = (float) dpToPx(2.5f);

        // --- ПРИГОТОВЛЕНИЕ КРАСОК ---

        // Глубокая тень для парения
        android.graphics.Paint shadowPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        shadowPaint.setColor(Color.WHITE);
        shadowPaint.setShadowLayer(dpToPx(12), 0, dpToPx(5), Color.parseColor("#44000000"));

        // Оранжевый неон
        android.graphics.Paint strokePaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        strokePaint.setColor(Color.parseColor("#FF9800"));
        strokePaint.setStyle(android.graphics.Paint.Style.STROKE);
        strokePaint.setStrokeWidth(strokeWidth);
        strokePaint.setStrokeCap(android.graphics.Paint.Cap.ROUND);

        // Белая обводка вокруг самого фото (чтобы отделить его от оранжевого кольца)
        android.graphics.Paint whiteBorderPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        whiteBorderPaint.setColor(Color.WHITE);
        whiteBorderPaint.setStyle(android.graphics.Paint.Style.STROKE);
        whiteBorderPaint.setStrokeWidth(dpToPx(2));

        // --- ЛОГИКА ЗАГРУЗКИ ФОТО ---
        android.graphics.Paint photoPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        boolean hasPhoto = !loc.photoPaths.isEmpty();

        if (hasPhoto) {
            try {
                android.net.Uri uri = android.net.Uri.parse(loc.photoPaths.get(loc.photoPaths.size() - 1)); // Берем последнее добавленное фото
                android.graphics.Bitmap source = android.provider.MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);

                // 1. Делаем фото квадратным (Center Crop)
                int size = Math.min(source.getWidth(), source.getHeight());
                int x = (source.getWidth() - size) / 2;
                int y = (source.getHeight() - size) / 2;
                android.graphics.Bitmap squared = android.graphics.Bitmap.createBitmap(source, x, y, size, size);

                // 2. Масштабируем под размер нашего маркера
                int targetDim = (int) (mainCircleRadius * 2);
                android.graphics.Bitmap scaled = android.graphics.Bitmap.createScaledBitmap(squared, targetDim, targetDim, true);

                // 3. Создаем шейдер для круглой отрисовки
                android.graphics.BitmapShader shader = new android.graphics.BitmapShader(scaled, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP);
                photoPaint.setShader(shader);

                // Очищаем временные битмапы для памяти
                if (source != squared) source.recycle();
            } catch (Exception e) {
                hasPhoto = false;
            }
        }

        // --- РИСОВАНИЕ ---

        canvas.drawCircle(center, center, mainCircleRadius, shadowPaint);

// 2. РИСУЕМ ФОТО (Или белое ядро)
        if (hasPhoto) {
            canvas.save();
            canvas.translate(center - mainCircleRadius, center - mainCircleRadius);
            canvas.drawCircle(mainCircleRadius, mainCircleRadius, mainCircleRadius, photoPaint);
            canvas.restore();
            // Белая кайма поверх фото, чтобы оно выглядело аккуратно
            canvas.drawCircle(center, center, mainCircleRadius, whiteBorderPaint);
        } else {
            android.graphics.Paint innerPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            innerPaint.setColor(Color.WHITE);
            canvas.drawCircle(center, center, mainCircleRadius, innerPaint);
        }

// 3. ТЕПЕРЬ РИСУЕМ ШЛЯПУ (PROGRESS ARC & BADGE)
// Важно: это должно быть ПОСЛЕ отрисовки фото, чтобы быть сверху!

        android.graphics.RectF arcRect = new android.graphics.RectF(
                center - arcRadius, center - arcRadius,
                center + arcRadius, center + arcRadius
        );

        if (loc.level <= 1) {
            // Уровень 1: Просто полное кольцо вокруг
            canvas.drawCircle(center, center, arcRadius, strokePaint);
        } else {
            // Уровень 2+: Разрывное кольцо и Badge с цифрой
            canvas.drawArc(arcRect, -70, 320, false, strokePaint);

            // Рисуем оранжевый Badge (кружок для цифры)
            android.graphics.Paint badgePaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            badgePaint.setColor(Color.parseColor("#FF9800"));
            float badgeRadius = dpToPx(9);
            float badgeY = center - arcRadius; // Позиция строго сверху

            // Рисуем сам кружок badge
            canvas.drawCircle(center, badgeY, badgeRadius, badgePaint);

            // Рисуем число уровня внутри badge
            android.graphics.Paint textPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(dpToPx(11));
            textPaint.setTypeface(android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL));
            textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);

            float textY = badgeY - ((textPaint.descent() + textPaint.ascent()) / 2f);
            canvas.drawText(String.valueOf(loc.level), center, textY, textPaint);
        }

        // --- СОХРАНЕНИЕ В КЭШ ---
        loc.cachedIcon = org.maplibre.android.annotations.IconFactory.getInstance(this).fromBitmap(bitmap);
        return loc.cachedIcon;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            MapLibre.getInstance(this);
            setContentView(R.layout.activity_main);
            // Находим кнопку настроек (шестеренку), которую мы добавили в topBar
            findViewById(R.id.btnSettings).setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
                // Добавим красивую анимацию перехода, если хочешь
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            });
            mapView = findViewById(R.id.mapView);
            if (mapView != null) mapView.onCreate(savedInstanceState);

            // Поиск карточки
            View infoCard = findViewById(R.id.infoCard);

            if (infoCard != null) {
                // Пытаемся привязать BottomSheet
                try {
                    sheetBehavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(infoCard);
                    sheetBehavior.setHideable(true);
                    sheetBehavior.setPeekHeight(450);
                    sheetBehavior.setHalfExpandedRatio(0.4f);
                    sheetBehavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED);
                    sheetBehavior.setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN);
                } catch (IllegalArgumentException e) {
                    // Это спасет от вылета, если в XML не CoordinatorLayout или нет атрибута Behavior
                    Toast.makeText(this, "Ошибка XML: Добавьте CoordinatorLayout!", Toast.LENGTH_LONG).show();
                }
            }
            sheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                @Override
                public void onStateChanged(@NonNull View bottomSheet, int newState) {
                    // Здесь теперь ничего скрывать не нужно, кнопка всегда видна
                }

                @Override
                public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                    View saveBtn = findViewById(R.id.btnSaveLocation);
                    if (saveBtn != null) {
                        // 1. Текущий верх карточки
                        float sheetTop = bottomSheet.getTop();

                        // 2. Рассчитываем, где кнопка находится "в покое" (над ползунком)
                        // screenHeight - marginBottom (110dp) - высота кнопки
                        int screenHeight = getResources().getDisplayMetrics().heightPixels;
                        float buttonDefaultTop = screenHeight - dpToPx(110) - saveBtn.getHeight();

                        // 3. Зазор между кнопкой и карточкой (например, 15dp)
                        float gap = dpToPx(15);

                        // Если верх карточки подошел слишком близко к низу кнопки
                        if (sheetTop < (buttonDefaultTop + saveBtn.getHeight() + gap)) {
                            // Вычисляем, насколько нужно "подпрыгнуть" кнопке
                            // Новое положение кнопки должно быть: sheetTop - gap - высота_кнопки
                            // Но так как мы меняем TranslationY, мы вычитаем это из начальной позиции
                            float targetY = sheetTop - gap - saveBtn.getHeight();
                            float offset = targetY - buttonDefaultTop;

                            saveBtn.setTranslationY(offset);
                        } else {
                            // Если карточка далеко — возвращаем кнопку на её законное место над ползунком
                            saveBtn.setTranslationY(0);
                        }
                    }
                }
            });
            setupButtons();

            if (mapView != null) {
                mapView.getMapAsync(map -> {
                    this.mapLibre = map;
                    String styleUrl = "https://tiles.openfreemap.org/styles/liberty";
                    map.setStyle(styleUrl, style -> {
                        // 1. ОТКЛЮЧАЕМ стандартный компас, чтобы он не маячил в углу
                        map.getUiSettings().setCompassEnabled(false);
                        map.getUiSettings().setAttributionEnabled(false);
                        map.getUiSettings().setLogoEnabled(false);
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(40.1792, 44.5134), 12), 2000);
                        enableLocation(style);
                    });
                    mapLibre.setOnMarkerClickListener(marker -> {
                        // 1. Находим, на какую именно базу нажал пользователь
                        SavedLocation clickedLoc = null;
                        for (SavedLocation loc : uniqueLocations) {
                            if (loc.latLng.equals(marker.getPosition())) {
                                clickedLoc = loc;
                                break;
                            }
                        }

                        if (clickedLoc != null) {
                            // 2. Показываем карточку с данными этой базы
                            showLocationCard(clickedLoc);
                        }

                        return true; // "true" значит, что мы сами обработали нажатие
                    });

                    // ДОБАВЛЯЕМ КЛИК ПО КАРТЕ
// СЛУШАТЕЛЬ ДЛИННОГО НАЖАТИЯ
                    map.addOnMapLongClickListener(point -> {
                        mapView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        // 1. Показываем визуальный "указатель" (пин) на карте
                        showMarkerAt(point.getLatitude(), point.getLongitude());

                        // 2. Запускаем поиск данных (тот метод, что мы создали ранее)
                        reverseSearch(point.getLatitude(), point.getLongitude());

                        // true означает, что событие обработано
                        return true;
                    });

                    // 2. ОБЫЧНЫЙ КЛИК (Очистка карты)
                    map.addOnMapClickListener(point -> {
                        android.graphics.PointF screenPoint = mapLibre.getProjection().toScreenLocation(point);
                        java.util.List<Feature> features = mapLibre.queryRenderedFeatures(screenPoint);

                        if (!features.isEmpty()) {
                            Feature feat = features.get(0);

                            // Скрываем оранжевые слои
                            hideManualOverlays();

                            if (feat.geometry() instanceof Point) {
                                Point p = (Point) feat.geometry();
                                // Вместо мгновенного вызова карточки, запускаем поиск адреса
                                // чтобы получить город и страну для этой аптеки/магазина
                                reverseSearch(p.latitude(), p.longitude());
                            }
                        } else {
                            clearMapOverlays();
                        }
                        return true;
                    });

                    map.addOnCameraMoveListener(() -> {
                        double bearing = map.getCameraPosition().bearing;

                        // БЫЛО: FloatingActionButton
                        // СТАЛО: ImageView
                        ImageView fabCompass = findViewById(R.id.fabCompass);
                        if (fabCompass != null) {
                            fabCompass.setRotation((float) -bearing);
                        }
                    });
                    map.addOnCameraMoveListener(() -> {
                        // 1. Убедимся, что метка включена и геолокация доступна
                        View centerMarker = findViewById(R.id.centerMarker);
                        LocationComponent locationComponent = map.getLocationComponent();

                        if (centerMarker != null && centerMarker.getVisibility() == View.VISIBLE
                                && locationComponent != null && locationComponent.getLastKnownLocation() != null) {

                            // 2. Получаем экранные координаты центра метки
                            android.graphics.PointF markerPoint = new android.graphics.PointF(
                                    centerMarker.getLeft() + centerMarker.getWidth() / 2f,
                                    centerMarker.getTop() + centerMarker.getHeight() / 2f
                            );

                            // 3. Получаем экранные координаты пользователя
                            LatLng userLatLng = new LatLng(
                                    locationComponent.getLastKnownLocation().getLatitude(),
                                    locationComponent.getLastKnownLocation().getLongitude()
                            );
                            android.graphics.PointF userPoint = map.getProjection().toScreenLocation(userLatLng);

                            // 4. Рассчитываем расстояние между ними (в пикселях)
                            double distance = Math.sqrt(
                                    Math.pow(markerPoint.x - userPoint.x, 2) +
                                            Math.pow(markerPoint.y - userPoint.y, 2)
                            );

                            // 5. ЛОГИКА СЛИЯНИЯ (Порог слияния - например, 50 пикселей)
                            float threshold = dpToPx(50); // Используем твой метод dpToPx

                            if (distance < threshold) {
                                // Расчет коэффициента слияния (от 0.0 до 1.0)
                                float fusionFactor = 1.0f - (float) (distance / threshold);

                                // --- ЭФФЕКТ СЛИЯНИЯ ---

                                // А. Метка немного сжимается, "обнимая" точку пользователя
                                float scale = 1.0f - (fusionFactor * 0.15f); // Сжатие до 85%
                                centerMarker.setScaleX(scale);
                                centerMarker.setScaleY(scale);

                                // Б. Метка становится немного ярче/насыщеннее (или добавляем свечение через Alpha)
                                centerMarker.setAlpha(0.8f + (fusionFactor * 0.2f)); // Поднимаем Alpha до 1.0

                                // В. Метка немного опускается, чтобы центр перекрестия совпал с точкой
                                // (Корректируем translationY, учитывая исходное смещение -2dp)
                                float translationY = dpToPx(-2) + (fusionFactor * dpToPx(2));
                                centerMarker.setTranslationY(translationY);

                            } else {
                                // --- ВОЗВРАТ К ОБЫЧНОМУ СОСТОЯНИЮ (Если пользователь далеко) ---
                                // Плавная анимация возврата (чтобы не дергалось)
                                centerMarker.animate().scaleX(1.0f).scaleY(1.0f).translationY(dpToPx(-2)).alpha(1.0f).setDuration(200).start();
                            }
                        }
                    });
                    mapLibre.addOnCameraMoveListener(() -> {
                        // 1. Берем координаты центра экрана (в LatLng и в Пикселях)
                        org.maplibre.android.geometry.LatLng centerLatLng = mapLibre.getCameraPosition().target;
                        android.graphics.PointF centerPoint = mapLibre.getProjection().toScreenLocation(centerLatLng);

                        for (SavedLocation loc : uniqueLocations) {
                            // 2. Переводим координаты каждой базы из LatLng в Пиксели экрана
                            android.graphics.PointF locPoint = mapLibre.getProjection().toScreenLocation(loc.latLng);

                            // 3. Считаем расстояние в пикселях (Геометрия: корень из суммы квадратов)
                            float dx = centerPoint.x - locPoint.x;
                            float dy = centerPoint.y - locPoint.y;
                            double distanceInPx = Math.sqrt(dx * dx + dy * dy);

                            // 4. Если палец (центр) ближе 40-50 пикселей к маркеру
                            if (distanceInPx < 50 && distanceInPx > 2) {
                                // Магнитим камеру прямо в центр объекта
                                mapLibre.easeCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLng(loc.latLng), 100);

                                // Вибрация "Захват"
                                findViewById(android.R.id.content).performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                                break;
                            }
                        }
                    });

                });

            }
        } catch (Exception e) {
            // Если что-то пойдет совсем не так, мы увидим текст ошибки вместо простого вылета
            Toast.makeText(this, "Критическая ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private void showLocationCard(SavedLocation loc) {
        com.google.android.material.bottomsheet.BottomSheetDialog dialog =
                new com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog);

        View view = getLayoutInflater().inflate(R.layout.layout_location_card, null);
        dialog.setContentView(view);

        // --- 1. ЗАГОЛОВОК И РЕДАКТИРОВАНИЕ ИМЕНИ ---
        TextView titleView = view.findViewById(R.id.cardTitle);
        View btnEdit = view.findViewById(R.id.btnEditTitle);

        if (titleView != null) {
            titleView.setText(loc.customName.isEmpty() ? "Точка на карте" : loc.customName);
        }

        if (btnEdit != null && titleView != null) {
            btnEdit.setOnClickListener(v -> {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);

                android.widget.EditText input = new android.widget.EditText(this);
                input.setText(loc.customName.isEmpty() ? titleView.getText() : loc.customName);
                input.setSelection(input.getText().length());
                input.setPadding(dpToPx(20), dpToPx(20), dpToPx(20), dpToPx(20));

                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Изменить название")
                        .setView(input)
                        .setPositiveButton("Сохранить", (d, which) -> {
                            String newName = input.getText().toString().trim();
                            if (!newName.isEmpty()) {
                                loc.customName = newName;
                                titleView.setText(newName);

                                // Сбрасываем кэш иконки, чтобы на карте обновился текст/вид
                                loc.cachedIcon = null;
                                refreshSavedPoints();

                                android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
                                imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                            }
                        })
                        .setNegativeButton("Отмена", null)
                        .show();
            });
        }

        // --- 2. ОПИСАНИЕ (ЗАМЕТКА) ---
        EditText descInput = view.findViewById(R.id.cardDescription);
        if (descInput != null) {
            descInput.setText(loc.note);
            descInput.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    loc.note = s.toString(); // Сохраняем заметку в объект
                }
                @Override public void afterTextChanged(android.text.Editable s) {}
            });
        }

        // --- 3. ФОТОГРАФИИ (ГОРИЗОНТАЛЬНЫЙ СПИСОК) ---
        android.widget.LinearLayout photoContainer = view.findViewById(R.id.photoContainer);
        if (photoContainer != null) {
            photoContainer.removeAllViews();
            int imgSize = (int) dpToPx(130);
            int btnSize = (int) dpToPx(34);

            for (int i = 0; i < loc.photoPaths.size(); i++) {
                final int photoIndex = i;
                String photoUriString = loc.photoPaths.get(i);

                android.widget.FrameLayout frameLayout = new android.widget.FrameLayout(this);
                android.widget.LinearLayout.LayoutParams frameParams = new android.widget.LinearLayout.LayoutParams(imgSize, imgSize);
                frameParams.setMargins(0, 0, (int) dpToPx(14), 0);
                frameLayout.setLayoutParams(frameParams);

                android.widget.ImageView imageView = new android.widget.ImageView(this);
                imageView.setLayoutParams(new android.widget.FrameLayout.LayoutParams(-1, -1));
                imageView.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                com.bumptech.glide.Glide.with(this).load(photoUriString).centerCrop().into(imageView);
                frameLayout.addView(imageView);

                // Кнопка удаления фото
                android.widget.ImageView btnDelete = new android.widget.ImageView(this);
                android.widget.FrameLayout.LayoutParams btnParams = new android.widget.FrameLayout.LayoutParams(btnSize, btnSize);
                btnParams.gravity = android.view.Gravity.TOP | android.view.Gravity.END;
                btnParams.setMargins(0, (int) dpToPx(5), (int) dpToPx(5), 0);
                btnDelete.setLayoutParams(btnParams);

                android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
                bg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                bg.setColor(Color.parseColor("#EEFF5252"));
                btnDelete.setBackground(bg);
                btnDelete.setImageResource(android.R.drawable.ic_menu_delete);
                btnDelete.setPadding((int) dpToPx(7), (int) dpToPx(7), (int) dpToPx(7), (int) dpToPx(7));
                btnDelete.setColorFilter(Color.WHITE);

                btnDelete.setOnClickListener(v -> {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                    loc.photoPaths.remove(photoIndex);
                    loc.cachedIcon = null;
                    refreshSavedPoints();
                    dialog.dismiss(); // Переоткрываем для обновления UI
                    showLocationCard(loc);
                });

                frameLayout.addView(btnDelete);
                photoContainer.addView(frameLayout);
            }
        }

        // --- 4. РЕЙТИНГ (СЛАЙДЕР) ---
        com.google.android.material.slider.Slider ratingSlider = view.findViewById(R.id.ratingSlider);
        if (ratingSlider != null) {
            ratingSlider.setValue(loc.rating);
            ratingSlider.addOnChangeListener((slider, value, fromUser) -> {
                if (fromUser) {
                    loc.rating = value; // Сохраняем рейтинг
                    if ((int) value % 10 == 0) {
                        slider.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                    }
                }
            });
        }
        View btnPickDate = view.findViewById(R.id.btnPickDate);
        TextView tvDateDisplay = view.findViewById(R.id.tvDateDisplay);

        // Внутри showLocationCard (после того, как нашел btnPickDate и tvDateDisplay)
        if (btnPickDate != null && tvDateDisplay != null) {
            // Отображаем дату из модели
            if (loc.date != null && !loc.date.isEmpty()) {
                tvDateDisplay.setText(loc.date);
                tvDateDisplay.setTextColor(Color.parseColor("#FF9800"));
            }

            btnPickDate.setOnClickListener(v -> {
                // 1. Тактильный отклик (сразу поймем, что нажатие прошло)
                v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);

                // 2. Получаем текущую дату
                java.util.Calendar c = java.util.Calendar.getInstance();
                int year = c.get(java.util.Calendar.YEAR);
                int month = c.get(java.util.Calendar.MONTH);
                int day = c.get(java.util.Calendar.DAY_OF_MONTH);

                // 3. Создаем диалог. ВАЖНО: используем MainActivity.this
                android.app.DatePickerDialog datePickerDialog = new android.app.DatePickerDialog(
                        MainActivity.this,
                        android.R.style.Theme_DeviceDefault_Dialog_Alert, // Системный темный стиль
                        (view1, year1, monthOfYear, dayOfMonth) -> {

                            // Форматируем дату красиво
                            java.util.Calendar sel = java.util.Calendar.getInstance();
                            sel.set(year1, monthOfYear, dayOfMonth);
                            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("dd MMMM yyyy", java.util.Locale.getDefault());
                            String formattedDate = format.format(sel.getTime());

                            // Сохраняем и обновляем UI
                            loc.date = formattedDate;
                            tvDateDisplay.setText(formattedDate);
                            tvDateDisplay.setTextColor(android.graphics.Color.parseColor("#FF9800"));
                        }, year, month, day);

                // 4. Показываем
                datePickerDialog.show();
            });
        }
        // Сохранение текста
        descInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                loc.note = s.toString();
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

// 1. Сначала находим кнопку в макете карточки
        Button btnAddPhoto = view.findViewById(R.id.btnAddPhoto);

// 2. Только если кнопка найдена, вешаем на неё клик
        if (btnAddPhoto != null) {
            btnAddPhoto.setOnClickListener(v -> {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);

                // Запоминаем, для какой именно локации мы сейчас будем выбирать фото
                currentlyEditingLocation = loc;

                // Закрываем диалог, чтобы открыть галерею (или можно оставить)
                dialog.dismiss();

                // Вызываем твой метод открытия галереи
                openGallery();
            });
        }
        dialog.getWindow().setWindowAnimations(R.style.DialogAnimation); // Нужно создать стиль анимации
        dialog.show();

    }
    // Новый способ: открывает именно фото-пикер с альбомами
    private final androidx.activity.result.ActivityResultLauncher<androidx.activity.result.PickVisualMediaRequest> pickMedia =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia(), uri -> {
                if (uri != null && currentlyEditingLocation != null) {
                    // Тот же код сохранения
                    currentlyEditingLocation.photoPaths.add(uri.toString());
                    currentlyEditingLocation.cachedIcon = null;
                    refreshSavedPoints();
                    showLocationCard(currentlyEditingLocation);
                }
            });

    // Исправленный метод openGallery
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Это подсказка системе показать именно внутреннее хранилище
        intent.putExtra("android.content.extra.SHOW_ADVANCED", true);

        // Запускаем через наш Launcher
        galleryLauncher.launch(intent);
    }
    // Регистратор для выбора картинки
    // 1. Объявляем лончер, который умеет принимать Intent
    private final androidx.activity.result.ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == android.app.Activity.RESULT_OK && result.getData() != null) {
                    android.net.Uri uri = result.getData().getData();
                    if (uri != null && currentlyEditingLocation != null) {
                        // Сохраняем путь к фото
                        currentlyEditingLocation.photoPaths.add(uri.toString());
                        currentlyEditingLocation.cachedIcon = null; // Сброс иконки для обновления

                        // Обновляем карту и переоткрываем карточку
                        refreshSavedPoints();
                        showLocationCard(currentlyEditingLocation);
                    }
                }
            });
    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1001 && resultCode == RESULT_OK && data != null && currentlyEditingLocation != null) {
            android.net.Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                // Сбрасываем старую иконку, чтобы метод createPremiumMarker перерисовал её с новым фото
                currentlyEditingLocation.cachedIcon = null;

                currentlyEditingLocation.photoPaths.add(selectedImageUri.toString());

                // Обновляем карту
                refreshSavedPoints();
                showLocationCard(currentlyEditingLocation);
            }
        }
    }
    private void hideManualOverlays() {
        mapLibre.getStyle(style -> {
            // Прячем ручную точку
            org.maplibre.android.style.layers.Layer marker = style.getLayer("marker-layer");
            org.maplibre.android.style.layers.Layer shadow = style.getLayer("marker-shadow");
            if (marker != null)
                marker.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));
            if (shadow != null)
                shadow.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));

            // Прячем границы районов
            if (style.getSource("boundary-source") != null) {
                style.removeLayer("boundary-layer");
                style.removeLayer("outline-layer");
                style.removeSource("boundary-source");
            }
        });
    }

    private void clearMapOverlays() {
        if (mapLibre == null) return;

        mapLibre.getStyle(style -> {
            // 1. Скрываем указатель (пин)
            org.maplibre.android.style.layers.Layer marker = style.getLayer("marker-layer");
            org.maplibre.android.style.layers.Layer shadow = style.getLayer("marker-shadow");
            if (marker != null)
                marker.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));
            if (shadow != null)
                shadow.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));

            // 2. Убираем границы районов
            if (style.getSource("boundary-source") != null) {
                style.removeLayer("boundary-layer");
                style.removeLayer("outline-layer");
                style.removeSource("boundary-source");
            }
        });

        // 3. Прячем карточку информации
        if (sheetBehavior != null) {
            sheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        }

        // Сбрасываем положение кнопки "Сохранить"
        View saveBtn = findViewById(R.id.btnSaveLocation);
        if (saveBtn != null) {
            saveBtn.animate().translationY(0).setDuration(300).start();
        }
    }

    private void showMarkerAt(double lat, double lon) {
        mapLibre.getStyle(style -> {
            // ПЕРВЫМ ДЕЛОМ: Удаляем старые границы, если они были
            if (style.getSource("boundary-source") != null) {
                style.removeLayer("boundary-layer");
                style.removeLayer("outline-layer");
                style.removeSource("boundary-source");
            }

            String geoJson = "{ \"type\": \"FeatureCollection\", \"features\": [{ \"type\": \"Feature\", \"geometry\": { \"type\": \"Point\", \"coordinates\": [" + lon + ", " + lat + "] } }] }";
            org.maplibre.android.style.sources.GeoJsonSource markerSource = (org.maplibre.android.style.sources.GeoJsonSource) style.getSource("selected-point-source");

            if (markerSource != null) {
                markerSource.setGeoJson(geoJson);
            } else {
                style.addSource(new org.maplibre.android.style.sources.GeoJsonSource("selected-point-source", geoJson));
                // Слой тени
                style.addLayer(new org.maplibre.android.style.layers.CircleLayer("marker-shadow", "selected-point-source")
                        .withProperties(
                                org.maplibre.android.style.layers.PropertyFactory.circleColor(Color.parseColor("#FF9800")),
                                org.maplibre.android.style.layers.PropertyFactory.circleRadius(12f),
                                org.maplibre.android.style.layers.PropertyFactory.circleBlur(0.8f),
                                org.maplibre.android.style.layers.PropertyFactory.circleOpacity(0.6f)
                        ));
                // Основной слой
                style.addLayer(new org.maplibre.android.style.layers.CircleLayer("marker-layer", "selected-point-source")
                        .withProperties(
                                org.maplibre.android.style.layers.PropertyFactory.circleColor(Color.parseColor("#FF9800")),
                                org.maplibre.android.style.layers.PropertyFactory.circleRadius(8f),
                                org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(Color.WHITE),
                                org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth(3f)
                        ));
            }

            // Гарантируем видимость точки (на случай если она была скрыта прошлым поиском района)
            org.maplibre.android.style.layers.Layer mainLayer = style.getLayer("marker-layer");
            if (mainLayer != null)
                mainLayer.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.VISIBLE));
        });
    }

    private void reverseSearch(double lat, double lon) {
        new Thread(() -> {
            try {
                String urlString = "https://nominatim.openstreetmap.org/reverse?format=json"
                        + "&lat=" + lat + "&lon=" + lon + "&zoom=18&addressdetails=1&accept-language=ru,en";

                URL url = new URL(urlString);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestProperty("User-Agent", "OzTrip_App");

                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder res = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) res.append(line);
                in.close();

                JSONObject result = new JSONObject(res.toString());
                String displayName = result.optString("display_name", "Неизвестное место");
                String shortName = displayName.split(",")[0];
                String type = result.optString("type", "point"); // ТИП ТУТ
                JSONObject geojson = result.optJSONObject("geojson");

                runOnUiThread(() -> {
                    // 1. Центрируем камеру
                    // Замени строку в runOnUiThread внутри reverseSearch:
                    CameraPosition pos = new CameraPosition.Builder()
                            .target(new LatLng(lat, lon))
                            .zoom(15.5f) // Чуть ближе для деталей
                            .tilt(0)    // Легкий наклон для 3D эффекта
                            .build();

                    mapLibre.animateCamera(CameraUpdateFactory.newCameraPosition(pos), 1200);

                    // 2. Определяем типы для карточки
                    String displayType = "Точка на карте";
                    // Внутри reverseSearch -> runOnUiThread
                    JSONObject address = result.optJSONObject("address");
                    String city = "";
                    String country = "";

                    if (address != null) {
                        // Nominatim может называть город по-разному: city, town, village или suburb
                        city = address.optString("city", address.optString("town", address.optString("village", address.optString("suburb", ""))));
                        country = address.optString("country", "");
                    }

// Формируем строку для нижней плашки (txtFlora)
                    String locationInfo = country;
                    if (!city.isEmpty()) {
                        locationInfo = city + ", " + country;
                    }
                    if (locationInfo.isEmpty()) locationInfo = "ПЛАНЕТА ЗЕМЛЯ";


                    // Вызываем карточку (передаем locationInfo в параметр floraType)
                    showPremiumCard(shortName, displayType, locationInfo.toUpperCase(), lat, lon);


                    // 4. Рисуем границы, если есть
                    if (geojson != null) drawBoundary(geojson);

                    // 5. УПРАВЛЕНИЕ УКАЗАТЕЛЕМ (Теперь внутри потока UI и после получения type)
                    mapLibre.getStyle(style -> {
                        org.maplibre.android.style.layers.Layer mainLayer = style.getLayer("marker-layer");
                        org.maplibre.android.style.layers.Layer shadowLayer = style.getLayer("marker-shadow");

                        if (mainLayer != null && shadowLayer != null) {
                            if (type.matches(".*(administrative|suburb|district|city|town).*")) {
                                // Если это территория — скрываем точку
                                mainLayer.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));
                                shadowLayer.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));
                            } else {
                                // Если это объект — показываем точку
                                mainLayer.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.VISIBLE));
                                shadowLayer.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.VISIBLE));
                            }
                        }
                    });
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Ошибка поиска", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void setupButtons() {
        // Поиск
        View btnSearch = findViewById(R.id.btnSearch);
        if (btnSearch != null) {
            btnSearch.setOnClickListener(v -> {
                android.widget.EditText input = new android.widget.EditText(this);
                input.setHint("Например: Ереван, Абовяна");
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Поиск места")
                        .setView(input)
                        .setPositiveButton("Найти", (d, w) -> {
                            String txt = input.getText().toString().trim();
                            if (!txt.isEmpty()) {
                                searchLocation(txt);
                            } else {
                                Toast.makeText(this, "Введите название места", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Отмена", null)
                        .show();
            });


        }
        View saveBtn = findViewById(R.id.btnSaveLocation);
        if (saveBtn != null) {
            saveBtn.setOnClickListener(v -> {
                org.maplibre.android.geometry.LatLng currentPos = mapLibre.getCameraPosition().target;
                SavedLocation existing = null;

                for (SavedLocation loc : uniqueLocations) {
                    if (currentPos.distanceTo(loc.latLng) < 1.0) {
                        existing = loc;
                        break;
                    }
                }

                if (existing != null) {
                    existing.level++;
                    // --- ВОТ ЭТА СТРОЧКА СПАСЕТ МИР ---
                    existing.cachedIcon = null;
                    // ---------------------------------
                    pathPoints.add(existing.latLng);
                } else {
                    SavedLocation newLoc = new SavedLocation(currentPos);
                    uniqueLocations.add(newLoc);
                    pathPoints.add(newLoc.latLng);
                }

                refreshSavedPoints(); // Теперь он создаст НОВУЮ иконку с правильной цифрой
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            });
        }

        // Кнопка закрытия карточки
        View btnClose = findViewById(R.id.btnCloseInfo);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> {
                if (sheetBehavior != null) {
                    sheetBehavior.setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN);
                }
            });
        }
        // Кнопка Компаса (выравнивание на Север)
        // Внутри setupButtons()
        View fabCompass = findViewById(R.id.fabCompass); // Здесь можно оставить View
        if (fabCompass != null) {
            fabCompass.setOnClickListener(v -> {
                if (mapLibre != null) {
                    CameraPosition pos = new CameraPosition.Builder(mapLibre.getCameraPosition())
                            .bearing(0)
                            .tilt(0)
                            .build();
                    mapLibre.animateCamera(CameraUpdateFactory.newCameraPosition(pos), 1000);
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                }
            });
        }
// Находим нашу новую оранжевую кнопку по ID
        final ImageView btnAction = findViewById(R.id.fabAction);

        if (btnAction != null) {
            btnAction.setOnClickListener(v -> {
                // Проверяем, что карта готова и геолокация включена
                if (mapLibre != null && mapLibre.getLocationComponent().getLastKnownLocation() != null) {

                    // 1. АНИМАЦИЯ НАЖАТИЯ (Luxury Spring Effect)
                    btnAction.animate().scaleX(0.8f).scaleY(0.8f).setDuration(150)
                            .withEndAction(() -> btnAction.animate().scaleX(1.0f).scaleY(1.0f).setDuration(150).start());

                    // 2. ВИБРАЦИЯ (Четкий клик прибора)
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);

                    // 3. ПОЛЕТ КАМЕРЫ: Плавно и быстро летим к пользователю
                    android.location.Location loc = mapLibre.getLocationComponent().getLastKnownLocation();
                    CameraPosition pos = new CameraPosition.Builder()
                            .target(new LatLng(loc.getLatitude(), loc.getLongitude()))
                            .zoom(16f) // Приближаем для фокуса
                            .bearing(0)
                            .tilt(0)
                            .build();

                    mapLibre.animateCamera(CameraUpdateFactory.newCameraPosition(pos), 2000);

                    Toast.makeText(this, "Поиск Вас...", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Поиск спутников...", Toast.LENGTH_SHORT).show();
                }
            });
        }

// 1. Находим кнопку ОДИН РАЗ
        final ImageView btnTarget = findViewById(R.id.fabTarget);

        if (btnTarget != null) {
            btnTarget.setOnClickListener(v -> {
                if (mapLibre != null) {
                    // 1. ЭФФЕКТ: Анимация кнопки (упругий клик)
                    btnTarget.animate().scaleX(0.85f).scaleY(0.85f).setDuration(100)
                            .withEndAction(() -> btnTarget.animate().scaleX(1.0f).scaleY(1.0f).start());

                    // 2. Вибрация
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);

                    // 3. ПРЯМОЙ ПОЛЕТ К БАЗЕ (homeLatLng)
                    // Мы убираем проверку GPS, чтобы кнопка всегда вела в одну точку
                    CameraPosition position = new CameraPosition.Builder()
                            .target(homeLatLng) // Твои координаты 40.1792, 44.5134
                            .zoom(15.5f)
                            .bearing(0)
                            .tilt(0)
                            .build();

                    mapLibre.animateCamera(CameraUpdateFactory.newCameraPosition(position), 2000);

                    Toast.makeText(this, "Возврат домой", Toast.LENGTH_SHORT).show();
                }
            });
        }


// Находим элементы


// Находим элементы
        final View centerMarker = findViewById(R.id.centerMarker);
        final ImageView imgToggle = findViewById(R.id.fabToggleMarker); // ImageView!

        if (imgToggle != null && centerMarker != null) {
            // 1. НАСТРОЙКА НАЧАЛЬНОГО СОСТОЯНИЯ (Default)
            centerMarker.setVisibility(View.VISIBLE);

            // Очищаем фильтры, ставим открытый глаз, кнопка яркая
            imgToggle.setImageResource(R.drawable.ic_btn_eye_open);
            imgToggle.clearColorFilter();
            imgToggle.setAlpha(1.0f);


            // 2. ОБРАБОТЧИК КЛИКА
            imgToggle.setOnClickListener(v -> {
                if (centerMarker.getVisibility() == View.VISIBLE) {
                    // СКРЫВАЕМ МЕТКУ С АНИМАЦИЕЙ
                    centerMarker.animate()
                            .alpha(0f)
                            .scaleX(0.5f)
                            .scaleY(0.5f)
                            .setDuration(200)
                            .withEndAction(() -> centerMarker.setVisibility(View.GONE));

                    // --- ЭФФЕКТ "ОСТЫВАНИЯ" И ПЕРЕЧЕРКИВАНИЯ КНОПКИ ---
                    // Анимация подмены иконки (сжатие и возврат)
                    imgToggle.animate().scaleX(0.8f).scaleY(0.8f).setDuration(100)
                            .withEndAction(() -> {
                                // Ставим перечеркнутый глаз
                                imgToggle.setImageResource(R.drawable.ic_btn_eye_closed);

                                // Применяем серый фильтр, чтобы кнопка "остыла"
                                imgToggle.setColorFilter(Color.parseColor("#757575"));
                                imgToggle.setAlpha(0.6f);

                                imgToggle.animate().scaleX(1.0f).scaleY(1.0f).start();
                            });

                    v.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK);

                    Toast.makeText(this, "Метка скрыта", Toast.LENGTH_SHORT).show();

                } else {
                    // ПОКАЗЫВАЕМ МЕТКУ
                    centerMarker.setVisibility(View.VISIBLE);
                    centerMarker.setScaleX(0.5f);
                    centerMarker.setScaleY(0.5f);
                    centerMarker.animate()
                            .alpha(1f)
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(250);

                    // --- ЭФФЕКТ "АКТИВАЦИИ" И ОТКРЫТИЯ КНОПКИ ---
                    // Анимация вспышки (увеличение и возврат)
                    imgToggle.animate().scaleX(1.1f).scaleY(1.1f).setDuration(150)
                            .withEndAction(() -> {
                                // Ставим открытый глаз
                                imgToggle.setImageResource(R.drawable.ic_btn_eye_open);

                                // Убираем серый фильтр, возвращая яркий оранжевый
                                imgToggle.clearColorFilter();
                                imgToggle.setAlpha(1.0f);

                                imgToggle.animate().scaleX(1.0f).scaleY(1.0f).start();
                            });

                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);

                    Toast.makeText(this, "Метка включена", Toast.LENGTH_SHORT).show();
                }
            });
        }


    }
    private void addSavedMarker(LatLng point) {
        if (mapLibre == null) return;

        // 1. Создаем временный объект для этой точки
        SavedLocation tempLoc = new SavedLocation(point);
        tempLoc.level = 1; // Устанавливаем уровень вручную

        // 2. Теперь передаем ОБЪЕКТ в метод отрисовки
        org.maplibre.android.annotations.Icon premiumIcon = createPremiumMarker(tempLoc);

        mapLibre.addMarker(new org.maplibre.android.annotations.MarkerOptions()
                .position(point)
                .icon(premiumIcon));
    }

    private void searchLocation(String query) {
        new Thread(() -> {
            try {
                // 1. Правильно кодируем запрос, чтобы пробелы не ломали URL
                String encodedQuery = java.net.URLEncoder.encode(query, "UTF-8");
                String urlString = "https://nominatim.openstreetmap.org/search?q=" + encodedQuery
                        + "&format=json&polygon_geojson=1&limit=1&accept-language=ru,en";

                URL url = new URL(urlString);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();

                // 2. Обязательные заголовки, чтобы сервер нас не заблокировал
                con.setRequestProperty("User-Agent", "OzTrip_App");
                con.setRequestProperty("Accept-Language", "ru,en");

                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder res = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) res.append(line);
                in.close();

                JSONArray results = new JSONArray(res.toString());

                if (results.length() > 0) {
                    JSONObject place = results.getJSONObject(0);
                    double lat = place.getDouble("lat");
                    double lon = place.getDouble("lon");
                    String fullDisplayName = place.optString("display_name", "");
                    String shortName = fullDisplayName.split(",")[0];
                    String type = place.optString("type", "Point");
                    JSONObject geojson = place.optJSONObject("geojson");

                    runOnUiThread(() -> {
                        // Плавный полет к найденной цели
                        mapLibre.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15), 2500);

                        if (geojson != null) drawBoundary(geojson);

                        // Определяем тип места для карточки
                        String displayType = "Объект";

                        if (type != null && !type.isEmpty()) {
                            String t = type.toLowerCase();

                            // --- ЛОГИКА ДЛЯ ПОДЗАГОЛОВКА (displayType) ---
                            if (t.matches(".*(city|town|administrative|suburb).*")) {
                                displayType = "Город / Район";
                            } else if (t.equals("village") || t.equals("hamlet")) {
                                displayType = "Деревня / Село";
                            } else if (t.contains("park") || t.contains("forest") || t.contains("wood") || t.equals("garden")) {
                                displayType = "Природная зона";
                            } else if (t.matches(".*(peak|mountain|volcano|hill).*")) {
                                displayType = "Горная вершина";
                            } else if (t.matches(".*(water|river|lake|reservoir|canal).*")) {
                                displayType = "Водный объект";
                            } else if (t.matches(".*(monastery|church|castle|fortress|ruins).*")) {
                                displayType = "Историческое место";
                            }



                        }
                        // Внутри searchLocation -> runOnUiThread
                        String[] parts = fullDisplayName.split(",");
                        String countryCity = "";

                        if (parts.length >= 2) {
                            // Берем последние два элемента (обычно это Город и Страна)
                            String last1 = parts[parts.length - 1].trim(); // Страна
                            String last2 = parts[parts.length - 2].trim(); // Город / Область
                            countryCity = last2 + ", " + last1;
                        } else {
                            countryCity = fullDisplayName;
                        }

                        showPremiumCard(shortName, displayType, countryCity.toUpperCase(), lat, lon);

                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Место не найдено. Попробуйте уточнить запрос.", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Ошибка сети: проверьте интернет", Toast.LENGTH_SHORT).show());
            }
        }).start();

    }

    private void showPremiumCard(String name, String subtitle, String type, double lat, double lon) {
        TextView title = findViewById(R.id.infoTitle);
        TextView desc = findViewById(R.id.infoDescription);
        ImageView img = findViewById(R.id.infoImage);
        TextView txtTemp = findViewById(R.id.txtTemp);
        TextView txtHeight = findViewById(R.id.txtHeight);
        TextView txtFlora = findViewById(R.id.txtFlora);
        // ПРИНУДИТЕЛЬНО ПОКАЗЫВАЕМ КНОПКУ ПЕРЕД ОТКРЫТИЕМ КАРТОЧКИ
        View saveBtn = findViewById(R.id.btnSaveLocation);
        if (saveBtn != null) {
            saveBtn.setVisibility(View.VISIBLE);
            saveBtn.setAlpha(1f);
        }

        if (sheetBehavior != null) {
            sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }




        // 2. Заполняем тексты
        if (title != null) title.setText(name);
        if (desc != null) desc.setText("📍 " + subtitle);
        if (txtFlora != null) {
            txtFlora.setText(type);
            txtFlora.setSelected(true); // Это запустит бегущую строку (marquee), если настроено в XML
        };

        // Высота (рандом для красоты или можно взять из API)
        if (txtHeight != null) txtHeight.setText("--m");
        // Внутри метода, где мы фиксируем локацию:
        this.homeLatLng = new LatLng(lat, lon);
        // 3. Спутниковый снимок (Яндекс.Карты)
        String hdUrl = "https://static-maps.yandex.ru/1.x/?ll=" + lon + "," + lat + "&z=16&l=sat&size=600,400";
        Glide.with(this).load(hdUrl).centerCrop().into(img);

        // 4. Погода
        if (txtTemp != null) fetchWeatherForCard(lat, lon, txtTemp);
    }

    // Добавь этот метод вниз класса
    private void fetchWeatherForCard(double lat, double lon, TextView tempView) {
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&current_weather=true";

        new Thread(() -> {
            try {
                java.net.URL obj = new java.net.URL(url);
                java.util.Scanner s = new java.util.Scanner(obj.openStream()).useDelimiter("\\A");
                String result = s.hasNext() ? s.next() : "";

                JSONObject json = new JSONObject(result);
                double temp = json.getJSONObject("current_weather").getDouble("temperature");

                runOnUiThread(() -> {
                    tempView.setText((int)temp + "°C");

                    // Получаем реальную высоту из JSON (Open-Meteo это умеет)
                    double elevation = json.optDouble("elevation", 0);
                    TextView heightView = findViewById(R.id.txtHeight);
                    if (heightView != null) heightView.setText((int)elevation + "m");});
            } catch (Exception e) {
                runOnUiThread(() -> tempView.setText("??°C"));
            }
        }).start();
    }

    private void refreshSavedPoints() {
        if (mapLibre == null) return;
        mapLibre.clear();

        for (SavedLocation loc : uniqueLocations) {
            mapLibre.addMarker(new org.maplibre.android.annotations.MarkerOptions()
                    .position(loc.latLng)
                    .icon(createPremiumMarker(loc))); // ПЕРЕДАЕМ ОБЪЕКТ
        }

        // 2. Рисуем линию ПО ВСЕМ НАЖАТИЯМ (Путь)
        if (pathPoints.size() > 1) {
            mapLibre.addPolyline(new org.maplibre.android.annotations.PolylineOptions()
                    .addAll(pathPoints)
                    .color(android.graphics.Color.parseColor("#A62C2C2C")) // Luxury Grey
                    .width(dpToPx(2)));
        }
    }
    private void drawBoundary(JSONObject geojson) {
        mapLibre.getStyle(style -> {
            // 1. ПРЯЧЕМ УКАЗАТЕЛЬ (Точку), так как теперь смотрим на район
            org.maplibre.android.style.layers.Layer marker = style.getLayer("marker-layer");
            org.maplibre.android.style.layers.Layer shadow = style.getLayer("marker-shadow");
            if (marker != null) marker.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));
            if (shadow != null) shadow.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(org.maplibre.android.style.layers.Property.NONE));

            // 2. РИСУЕМ ГРАНИЦЫ
            if (style.getSource("boundary-source") != null) {
                style.removeLayer("boundary-layer");
                style.removeLayer("outline-layer");
                style.removeSource("boundary-source");
            }
            style.addSource(new org.maplibre.android.style.sources.GeoJsonSource("boundary-source", geojson.toString()));
            style.addLayer(new org.maplibre.android.style.layers.FillLayer("boundary-layer", "boundary-source")
                    .withProperties(org.maplibre.android.style.layers.PropertyFactory.fillColor(Color.parseColor("#33FF9800"))));
            style.addLayer(new org.maplibre.android.style.layers.LineLayer("outline-layer", "boundary-source")
                    .withProperties(org.maplibre.android.style.layers.PropertyFactory.lineColor(Color.parseColor("#FF9800")),
                            org.maplibre.android.style.layers.PropertyFactory.lineWidth(2f)));
        });
    }

    // Этот метод сработает, когда ты пишешь dpToPx(52)
    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    // Этот метод сработает, когда ты пишешь dpToPx(1.5f)
    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    @SuppressWarnings({"MissingPermission"})
    private void enableLocation(Style style) {
        LocationComponent locationComponent = mapLibre.getLocationComponent();
        locationComponent.activateLocationComponent(LocationComponentActivationOptions.builder(this, style).build());
        locationComponent.setLocationComponentEnabled(true);
        locationComponent.setRenderMode(org.maplibre.android.location.modes.RenderMode.COMPASS);
    }

    @Override protected void onStart() { super.onStart(); if (mapView != null) mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); if (mapView != null) mapView.onResume(); }
    @Override protected void onPause() { super.onPause(); if (mapView != null) mapView.onPause(); }
    @Override protected void onStop() { super.onStop(); if (mapView != null) mapView.onStop(); }
    @Override protected void onSaveInstanceState(@NonNull Bundle outState) { super.onSaveInstanceState(outState); if (mapView != null) mapView.onSaveInstanceState(outState); }
    @Override public void onLowMemory() { super.onLowMemory(); if (mapView != null) mapView.onLowMemory(); }
    @Override protected void onDestroy() { super.onDestroy(); if (mapView != null) mapView.onDestroy(); }
}