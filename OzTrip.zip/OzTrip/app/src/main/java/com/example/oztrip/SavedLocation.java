package com.example.oztrip;

import org.maplibre.android.geometry.LatLng;

// Уникальное место сохранения
public class SavedLocation {
    public org.maplibre.android.annotations.Icon cachedIcon = null;
    public float rating = 50f; // Оценка по умолчанию (середина)
    public LatLng latLng;
    public int level;
    public String note = ""; // Для текста
    public String customName = "";
    public String date = ""; // По умолчанию пусто
    public java.util.List<String> photoPaths = new java.util.ArrayList<>(); // Для картинок

    public SavedLocation(LatLng latLng) {
        this.latLng = latLng;
        this.level = 1;
    }
}